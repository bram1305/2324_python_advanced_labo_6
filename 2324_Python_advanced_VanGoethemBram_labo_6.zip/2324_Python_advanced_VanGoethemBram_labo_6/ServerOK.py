import sys
import json
import subprocess
from datetime import datetime

# Define the names of the files we'll use to store the server list and log
SERVERS_FILE = "servers.json"
LOG_FILE = "log.json"
REPORT_FILE = "report.html"
# HTML template
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Server Status Report</title>
</head>
<body>
    <h1>Server Status Report</h1>
    <table>
        <tr>
            <th>Server</th>
            <th>Status</th>
            <th>Time</th>
        </tr>
        {rows}
    </table>
</body>
</html>
"""


# Load the list of servers from the JSON file
def load_servers():
    try:
        with open(SERVERS_FILE, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return []


# Save the list of servers to the JSON file
def save_servers(servers):
    with open(SERVERS_FILE, "w") as f:
        json.dump(servers, f)


# Load the log from the JSON file
def load_log():
    try:
        with open(LOG_FILE, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}


# Save the log to the JSON file
def save_log(log):
    with open(LOG_FILE, "w") as f:
        json.dump(log, f)


# Ping a server and return True if it's online, False if not
def ping(server):
    response = subprocess.run(
        ["ping", "-n", "1", server], stdout=subprocess.PIPE
    )  # Flake8(E501)
    return response.returncode == 0


# Check all servers and update the log
def check_servers():
    servers = load_servers()
    log = load_log()
    for server in servers:
        online = ping(server)
        log[server] = {"time": datetime.now().isoformat(), "online": online}
    save_log(log)


# Generate the HTML report
def generate_report():
    log = load_log()
    rows = ""
    for server, info in log.items():
        status = "Online" if info["online"] else "Offline"
        rows += f'<tr><td>{server}</td><td>{status}</td><td>{info["time"]}</td></tr>'
    report = HTML_TEMPLATE.format(rows=rows)
    with open(REPORT_FILE, "w") as f:
        f.write(report)


# Interactively manage the list of servers
def manage_servers():
    servers = load_servers()
    while True:
        print("Servers:", ", ".join(servers))
        print("1. Add server")
        print("2. Remove server")
        print("3. Back")
        choice = input("Choose an option: ")
        if choice == "1":
            server = input("Enter server IP or hostname: ")
            servers.append(server)
        elif choice == "2":
            server = input("Enter server IP or hostname: ")
            servers.remove(server)
        elif choice == "3":
            break
        else:
            print("Invalid option")
        save_servers(servers)


# The main function decides whether to check servers or manage
# them based on command line arguments
def main():
    if len(sys.argv) > 1 and sys.argv[1] == "check":
        check_servers()
        generate_report()
    else:
        manage_servers()


# This line means that the main function will be run
# when the script is executed directly
if __name__ == "__main__":
    main()
